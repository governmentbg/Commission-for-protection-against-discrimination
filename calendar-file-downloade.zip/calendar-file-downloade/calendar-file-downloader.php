<?php
/*
Plugin Name: Calendar File Downloader
Description: Качване и сваляне на файлове по дати чрез календар.
Version: 1.4
Author: Ти
*/

add_action('admin_menu', 'cfd_add_admin_menu');
add_action('admin_init', 'cfd_handle_upload');
add_shortcode('calendar_file_download', 'cfd_display_calendar');

function cfd_add_admin_menu() {
    add_menu_page('Файлов календар', 'Файлов календар', 'manage_options', 'cfd-calendar', 'cfd_admin_page');
}

function cfd_handle_upload() {
    if (!isset($_POST['cfd_upload']) || !current_user_can('manage_options')) return;
    $date = sanitize_text_field($_POST['cfd_date']);
    $file = $_FILES['cfd_file'];
    if ($file && $file['tmp_name']) {
        $upload = wp_upload_bits($file['name'], null, file_get_contents($file['tmp_name']));
        if (!$upload['error']) {
            $uploads = get_option('cfd_uploads', []);
            $uploads[$date][] = $upload['url'];
            update_option('cfd_uploads', $uploads);
        }
    }
}

function cfd_admin_page() {
    $uploads = get_option('cfd_uploads', []);
    ?>
    <div class="wrap">
        <h2>Качи файл по дата</h2>
        <form method="post" enctype="multipart/form-data">
            <label>Качи файл тук:</label>
            <input type="file" name="cfd_file" required>
            <br><br>
            <label>Избери дата тук:</label>
            <input type="date" name="cfd_date" required>
            <br><br>
            <input type="submit" name="cfd_upload" class="button button-primary" value="Качи">
        </form>
        <h3>Качени файлове:</h3>
        <ul>
        <?php foreach ($uploads as $date => $files): ?>
            <li><strong><?php echo esc_html($date); ?>:</strong>
                <ul>
                <?php foreach ($files as $index => $file):
                    $filename = basename($file);
                ?>
                    <li>📄 <?php echo esc_html($filename); ?> |
                        <a href="<?php echo esc_url($file); ?>" target="_blank">Отвори</a> |
                        <a href="?page=cfd-calendar&delete_date=<?php echo esc_attr($date); ?>&file_index=<?php echo $index; ?>">Изтрий</a>
                    </li>
                <?php endforeach; ?>
                </ul>
            </li>
        <?php endforeach; ?>
        </ul>
    </div>
    <?php
    if (isset($_GET['delete_date'], $_GET['file_index'])) {
        $date = $_GET['delete_date'];
        $index = (int)$_GET['file_index'];
        if (isset($uploads[$date][$index])) {
            unset($uploads[$date][$index]);
            if (empty($uploads[$date])) unset($uploads[$date]);
            update_option('cfd_uploads', $uploads);
            echo "<script>location.href='?page=cfd-calendar';</script>";
        }
    }
}

function cfd_display_calendar() {
    wp_enqueue_script('jquery-ui-datepicker');
    wp_enqueue_style('jquery-ui', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
    $uploads = get_option('cfd_uploads', []);
    $upload_dates = array_keys($uploads);
    ob_start();
    ?>
    <div id="datepicker-inline"></div>
    <div id="cfd-file-list" style="margin-top:15px;"></div>
    <script>
    jQuery(document).ready(function($) {
        var uploads = <?php echo json_encode($uploads); ?>;
        var uploadDates = <?php echo json_encode($upload_dates); ?>;
        $("#datepicker-inline").datepicker({
            dateFormat: 'yy-mm-dd',
            beforeShowDay: function(date) {
                var y = date.getFullYear();
                var m = ("0" + (date.getMonth() + 1)).slice(-2);
                var d = ("0" + date.getDate()).slice(-2);
                var dateStr = y + "-" + m + "-" + d;
                if (uploadDates.indexOf(dateStr) !== -1) {
                    return [true, "cfd-has-file", "Има файлове"];
                }
                return [true, "", ""];
            },
            onSelect: function(dateText) {
                var container = $("#cfd-file-list");
                if (uploads[dateText] && uploads[dateText].length > 0) {
                    var html = '<div class="cfd-download-box">';
                    html += '<strong>📅 Файлове за ' + dateText + ':</strong><ul>';
                    uploads[dateText].forEach(function(url) {
                        var name = url.split('/').pop();
                        var dlUrl = '/newsite/cfd-download.php?file=' + encodeURIComponent(url);
                        html += '<li>📄 <a href="' + dlUrl + '">' + decodeURIComponent(name) + ' ⬇</a></li>';
                    });
                    html += '</ul></div>';
                    container.html(html);
                } else {
                    container.html('<p style="color:#888;">Няма файлове за ' + dateText + '</p>');
                }
            }
        });
    });
    </script>
    <style>
    .cfd-has-file { background: none !important; border-radius: 0 !important; }
#datepicker-inline .ui-datepicker-calendar .cfd-has-file a { color: #f9c21a !important; font-weight: bold !important; }
#datepicker-inline .ui-datepicker-calendar .cfd-has-file span { color: #f9c21a !important; font-weight: bold !important; }
    .cfd-download-box { background:#f0f7f0; border:1px solid #c8e6c9; border-radius:8px; padding:15px 20px; max-width:500px; }
    .cfd-download-box strong { display:block; margin-bottom:8px; color:#2e7d32; }
    .cfd-download-box ul { list-style:none; padding:0; margin:0; }
    .cfd-download-box li { padding:6px 0; }
    .cfd-download-box a { color:#1565c0; text-decoration:none; font-weight:500; font-size:15px; }
    .cfd-download-box a:hover { text-decoration:underline; }
    </style>
    <?php
    return ob_get_clean();
}
