<?php
/* Must-Use Plugin: Keyboard style fix */
add_action('wp_head', function() {
    if (!class_exists('GFForms')) return;
    echo '<style>
.gfck-keyboard { display:none!important; background:#4a4a4a!important; border:1px solid #555!important; box-shadow:0 4px 16px rgba(0,0,0,.25)!important; }
.gfck-keyboard.gfck-open { display:flex!important; }
.gfck-key { background:#5c5c5c!important; color:#fff!important; border-color:#666!important; }
.gfck-key:hover { background:#777!important; }
.gfck-key--backspace { background:#6b3a3a!important; }
.gfck-key--close { background:#7a4a4a!important; color:#fdd!important; }
.gfck-key--shift[aria-pressed="true"] { background:#3a6b4a!important; }
.gfck-key--space { background:#555!important; }
.gfck-toggle-btn {
    background:#666!important; color:#fff!important; border-color:#999!important;
    width:auto!important; height:auto!important;
    padding:6px 12px!important;
    font-size:13px!important;
    border-radius:5px!important;
    display:inline-flex!important;
    align-items:center!important;
    gap:5px!important;
    white-space:nowrap!important;
}
.gfck-toggle-btn:hover { background:#555!important; }
</style>';
}, 999);

add_action('wp_footer', function() {
    if (!class_exists('GFForms')) return;
    ?><script>
(function(){
    var done = false;
    function fixKb() {
        if (done) return;
        var kbs = document.querySelectorAll('.gfck-keyboard');
        if (!kbs.length) return;
        done = true;

        /* Затвори всички при зареждане */
        kbs.forEach(function(kb) { kb.classList.remove('gfck-open'); });

        /* Оправяме текста на бутоните */
        document.querySelectorAll('.gfck-toggle-btn').forEach(function(btn) {
            btn.innerHTML = '⌨ Виртуална клавиатура';
        });

        /* Показвай при фокус, скривай при blur */
        document.querySelectorAll('.gfck-field-wrapper').forEach(function(wrap) {
            var input = wrap.querySelector('input, textarea');
            var kb = wrap.querySelector('.gfck-keyboard');
            var btn = wrap.querySelector('.gfck-toggle-btn');
            if (!input || !kb) return;

            input.addEventListener('focus', function() {
                document.querySelectorAll('.gfck-keyboard.gfck-open').forEach(function(o) {
                    if (o !== kb) o.classList.remove('gfck-open');
                });
                kb.classList.add('gfck-open');
                if (btn) btn.setAttribute('aria-pressed','true');
            });

            input.addEventListener('blur', function() {
                setTimeout(function() {
                    if (!kb.contains(document.activeElement) && document.activeElement !== btn) {
                        kb.classList.remove('gfck-open');
                        if (btn) btn.setAttribute('aria-pressed','false');
                    }
                }, 200);
            });

            kb.addEventListener('mousedown', function(e) { e.preventDefault(); });

            /* Fix close бутон */
            var closeBtn = kb.querySelector('.gfck-key--close');
            if (closeBtn) {
                closeBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    kb.classList.remove('gfck-open');
                    if (btn) {
                        btn.setAttribute('aria-pressed','false');
                        btn.focus();
                    }
                });
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function() { setTimeout(fixKb, 500); });
    if (window.jQuery) jQuery(document).on('gform_post_render', function() { setTimeout(fixKb, 500); });
})();
</script><?php
}, 100);