<?php
add_action('wp_footer', function() {
    $uploads = get_option('cfd_uploads', []);
    if (empty($uploads)) return;
    // Поправяме URL-ите - добавяме /newsite/ ако липсва
    $fixed = [];
    foreach ($uploads as $date => $files) {
        $fixed[$date] = [];
        foreach ($files as $url) {
            $url = str_replace(
                'kzd-nondiscrimination.com/wp-content/',
                'kzd-nondiscrimination.com/newsite/wp-content/',
                $url
            );
            $fixed[$date][] = $url;
        }
    }
    ?>
    <script>
    jQuery(document).ready(function($) {
        var uploads = <?php echo json_encode($fixed); ?>;
        var uploadDates = <?php echo json_encode(array_keys($fixed)); ?>;
        setTimeout(function() {
            var dp = $("#datepicker-inline");
            if (!dp.length) return;
            dp.datepicker("destroy");
            if (!$("#cfd-file-list").length) {
                dp.after('<div id="cfd-file-list" style="margin-top:15px;"></div>');
            }
            dp.datepicker({
                dateFormat: 'yy-mm-dd',
                beforeShowDay: function(date) {
                    var y = date.getFullYear();
                    var m = ("0" + (date.getMonth() + 1)).slice(-2);
                    var d = ("0" + date.getDate()).slice(-2);
                    var ds = y + "-" + m + "-" + d;
                    if (uploadDates.indexOf(ds) !== -1) return [true, "cfd-has-file", ""];
                    return [true, "", ""];
                },
                onSelect: function(dateText) {
                    var c = document.getElementById("cfd-file-list");
                    if (uploads[dateText] && uploads[dateText].length > 0) {
                        var h = '<div style="background:#f0f7f0;border:1px solid #c8e6c9;border-radius:8px;padding:15px 20px;max-width:600px;">';
                        h += '<b style="color:#2e7d32;">Файлове за ' + dateText + ':</b><br><br>';
                        uploads[dateText].forEach(function(url) {
                            var name = url.split('/').pop();
                            h += '<div style="margin:8px 0;"><a href="' + url + '" target="_blank" style="display:inline-block;padding:12px 24px;background:#2e7d32;color:#fff !important;border-radius:6px;font-size:15px;font-weight:600;text-decoration:none;cursor:pointer;">' + decodeURIComponent(name) + ' ⬇ СВАЛИ</a></div>';
                        });
                        h += '</div>';
                        c.innerHTML = h;
                    } else {
                        c.innerHTML = '<p style="color:#888;">Няма файлове за ' + dateText + '</p>';
                    }
                }
            });
        }, 1000);
    });
    </script>
    <style>
    .cfd-has-file{background:#2e7d32 !important;border-radius:50% !important}
    .cfd-has-file a,.cfd-has-file span{color:#fff !important;font-weight:bold !important}
    #cfd-file-list a{pointer-events:auto !important;position:relative;z-index:9999}
    </style>
    <?php
}, 999);
