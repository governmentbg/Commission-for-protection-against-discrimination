<?php
/**
 * Plugin Name: KZD BISS - Визуализация на подпис в записите
 * Description: Показва CN на подписващия, имейл, дата и подпис в Gravity Forms записите
 * Version:     1.0.0
 * Author:      KZD Development Team
 * Requires:    Gravity Forms, KZD BISS Signing Plugin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Ако KZD_BISS_FORM_ID не е дефинирано от основния плъгин,
 * задаваме стойност по подразбиране.
 */
if ( ! defined( 'KZD_BISS_FORM_ID' ) ) {
    define( 'KZD_BISS_FORM_ID', 1 );
}

class KZD_BISS_Entry_Display {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Meta box в detail view на entry-то
        add_filter( 'gform_entry_detail_meta_boxes', [ $this, 'add_signature_meta_box' ], 10, 3 );

        // Колона "Подписващ (CN)" в списъка с entries
        add_filter( 'gform_entry_list_columns', [ $this, 'add_signer_column' ], 10, 2 );

        // Стойност на колоната
        add_filter( 'gform_entries_column_filter', [ $this, 'render_signer_column' ], 10, 4 );

        // Добавя custom merge tag {biss_signer_cn} за използване в нотификации
        add_filter( 'gform_custom_merge_tags', [ $this, 'add_merge_tags' ], 10, 4 );
        add_filter( 'gform_replace_merge_tags', [ $this, 'replace_merge_tags' ], 10, 7 );

        // CSS за admin
        add_action( 'admin_head', [ $this, 'admin_css' ] );
    }

    /* ================================================================
     * 1. META BOX В DETAIL VIEW
     * ================================================================ */

    /**
     * Регистрира meta box "Електронен подпис (КЕП)" в detail view
     */
    public function add_signature_meta_box( $meta_boxes, $entry, $form ) {
        // Показваме за всички форми, които имат BISS подпис
        // (не само за KZD_BISS_FORM_ID, за да е по-гъвкаво)
        $signature = gform_get_meta( $entry['id'], 'biss_signature' );

        if ( ! empty( $signature ) ) {
            $meta_boxes['kzd_biss_signature_info'] = [
                'title'    => esc_html__( '🔐 Електронен подпис (КЕП)', 'kzd-biss' ),
                'callback' => [ $this, 'render_signature_meta_box' ],
                'context'  => 'normal',
                'priority' => 'high',
            ];
        }

        return $meta_boxes;
    }

    /**
     * Рендира съдържанието на meta box-а
     */
    public function render_signature_meta_box( $args ) {
        $entry = $args['entry'];

        $signer_cn    = gform_get_meta( $entry['id'], 'biss_signer_cn' );
        $signer_email = gform_get_meta( $entry['id'], 'biss_signer_email' );
        $timestamp    = gform_get_meta( $entry['id'], 'biss_sign_timestamp' );
        $signature    = gform_get_meta( $entry['id'], 'biss_signature' );
        $cert_chain   = gform_get_meta( $entry['id'], 'biss_cert_chain' );
        $session_id   = gform_get_meta( $entry['id'], 'biss_sign_session' );

        // Опит за извличане на допълнителна информация от сертификата
        $cert_details = $this->parse_certificate_details( $cert_chain );

        ?>
        <div class="kzd-biss-entry-info">
            <table class="widefat kzd-biss-table">
                <tbody>
                    <!-- Основна информация -->
                    <tr>
                        <th class="kzd-biss-label">
                            <span class="dashicons dashicons-businessman"></span>
                            Подписващ (CN):
                        </th>
                        <td>
                            <strong class="kzd-biss-cn"><?php echo esc_html( $signer_cn ?: '—' ); ?></strong>
                        </td>
                    </tr>

                    <tr>
                        <th class="kzd-biss-label">
                            <span class="dashicons dashicons-email"></span>
                            Имейл:
                        </th>
                        <td><?php echo esc_html( $signer_email ?: '—' ); ?></td>
                    </tr>

                    <tr>
                        <th class="kzd-biss-label">
                            <span class="dashicons dashicons-calendar-alt"></span>
                            Дата на подписване:
                        </th>
                        <td>
                            <?php
                            if ( $timestamp ) {
                                // Форматиране на датата
                                $dt = date_create( $timestamp );
                                if ( $dt ) {
                                    echo esc_html( $dt->format( 'd.m.Y H:i:s' ) );
                                    echo ' <span class="description">(' . esc_html( $timestamp ) . ')</span>';
                                } else {
                                    echo esc_html( $timestamp );
                                }
                            } else {
                                echo '—';
                            }
                            ?>
                        </td>
                    </tr>

                    <?php if ( ! empty( $cert_details ) ) : ?>
                        <!-- Детайли от сертификата -->
                        <?php if ( ! empty( $cert_details['issuer'] ) ) : ?>
                        <tr>
                            <th class="kzd-biss-label">
                                <span class="dashicons dashicons-shield"></span>
                                Издател (Issuer):
                            </th>
                            <td><?php echo esc_html( $cert_details['issuer'] ); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if ( ! empty( $cert_details['serial'] ) ) : ?>
                        <tr>
                            <th class="kzd-biss-label">
                                <span class="dashicons dashicons-tag"></span>
                                Сериен номер:
                            </th>
                            <td><code><?php echo esc_html( $cert_details['serial'] ); ?></code></td>
                        </tr>
                        <?php endif; ?>

                        <?php if ( ! empty( $cert_details['valid_from'] ) ) : ?>
                        <tr>
                            <th class="kzd-biss-label">
                                <span class="dashicons dashicons-calendar"></span>
                                Валиден от:
                            </th>
                            <td><?php echo esc_html( $cert_details['valid_from'] ); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if ( ! empty( $cert_details['valid_to'] ) ) : ?>
                        <tr>
                            <th class="kzd-biss-label">
                                <span class="dashicons dashicons-calendar"></span>
                                Валиден до:
                            </th>
                            <td>
                                <?php
                                echo esc_html( $cert_details['valid_to'] );
                                // Проверка дали сертификатът е изтекъл
                                if ( ! empty( $cert_details['valid_to_timestamp'] ) && $cert_details['valid_to_timestamp'] < time() ) {
                                    echo ' <span class="kzd-biss-expired">⚠️ ИЗТЕКЪЛ</span>';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endif; ?>

                        <?php if ( ! empty( $cert_details['organization'] ) ) : ?>
                        <tr>
                            <th class="kzd-biss-label">
                                <span class="dashicons dashicons-building"></span>
                                Организация:
                            </th>
                            <td><?php echo esc_html( $cert_details['organization'] ); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if ( ! empty( $cert_details['pid'] ) ) : ?>
                        <tr>
                            <th class="kzd-biss-label">
                                <span class="dashicons dashicons-id"></span>
                                PID / ЕГН:
                            </th>
                            <td><code><?php echo esc_html( $cert_details['pid'] ); ?></code></td>
                        </tr>
                        <?php endif; ?>
                    <?php endif; ?>

                    <!-- Подпис (съкратен) -->
                    <tr>
                        <th class="kzd-biss-label">
                            <span class="dashicons dashicons-lock"></span>
                            Подпис:
                        </th>
                        <td>
                            <details>
                                <summary>
                                    <code class="kzd-biss-sig-preview"><?php echo esc_html( substr( $signature, 0, 60 ) ); ?>…</code>
                                </summary>
                                <textarea class="kzd-biss-sig-full" readonly rows="4"><?php echo esc_textarea( $signature ); ?></textarea>
                            </details>
                        </td>
                    </tr>

                    <?php if ( $session_id ) : ?>
                    <tr>
                        <th class="kzd-biss-label">
                            <span class="dashicons dashicons-admin-network"></span>
                            Session ID:
                        </th>
                        <td><code><?php echo esc_html( $session_id ); ?></code></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="kzd-biss-verification-badge">
                ✅ Формата е подписана електронно с КЕП
            </div>
        </div>
        <?php
    }

    /**
     * Парсира сертификатната верига и извлича детайли от leaf сертификата
     */
    private function parse_certificate_details( $cert_chain_data ) {
        if ( empty( $cert_chain_data ) ) {
            return [];
        }

        // cert_chain може да е JSON масив от base64 сертификати
        $certs = json_decode( $cert_chain_data, true );

        if ( ! is_array( $certs ) || empty( $certs ) ) {
            // Опит да го третираме като единичен PEM или base64
            $certs = [ $cert_chain_data ];
        }

        // Вземаме leaf (първия) сертификат
        $leaf_b64 = $certs[0];

        // Ако е PEM формат, извличаме base64
        if ( strpos( $leaf_b64, '-----BEGIN CERTIFICATE-----' ) !== false ) {
            $leaf_b64 = str_replace(
                [ '-----BEGIN CERTIFICATE-----', '-----END CERTIFICATE-----', "\r", "\n", ' ' ],
                '',
                $leaf_b64
            );
        }

        $leaf_b64 = trim( $leaf_b64 );
        if ( empty( $leaf_b64 ) ) {
            return [];
        }

        // Декодираме и парсираме с openssl
        $pem = "-----BEGIN CERTIFICATE-----\n" . chunk_split( $leaf_b64, 64, "\n" ) . "-----END CERTIFICATE-----";

        $cert_info = @openssl_x509_parse( $pem );
        if ( ! $cert_info ) {
            return [];
        }

        $details = [];

        // CN
        if ( ! empty( $cert_info['subject']['CN'] ) ) {
            $details['cn'] = $cert_info['subject']['CN'];
        }

        // Email
        if ( ! empty( $cert_info['subject']['emailAddress'] ) ) {
            $details['email'] = $cert_info['subject']['emailAddress'];
        }

        // Организация
        if ( ! empty( $cert_info['subject']['O'] ) ) {
            $details['organization'] = $cert_info['subject']['O'];
        }

        // Issuer
        $issuer_parts = [];
        if ( ! empty( $cert_info['issuer']['CN'] ) ) {
            $issuer_parts[] = $cert_info['issuer']['CN'];
        }
        if ( ! empty( $cert_info['issuer']['O'] ) ) {
            $issuer_parts[] = $cert_info['issuer']['O'];
        }
        if ( $issuer_parts ) {
            $details['issuer'] = implode( ', ', $issuer_parts );
        }

        // Сериен номер
        if ( ! empty( $cert_info['serialNumberHex'] ) ) {
            $details['serial'] = strtoupper( $cert_info['serialNumberHex'] );
        } elseif ( ! empty( $cert_info['serialNumber'] ) ) {
            $details['serial'] = $cert_info['serialNumber'];
        }

        // Валидност
        if ( ! empty( $cert_info['validFrom_time_t'] ) ) {
            $details['valid_from'] = date( 'd.m.Y H:i', $cert_info['validFrom_time_t'] );
        }
        if ( ! empty( $cert_info['validTo_time_t'] ) ) {
            $details['valid_to'] = date( 'd.m.Y H:i', $cert_info['validTo_time_t'] );
            $details['valid_to_timestamp'] = $cert_info['validTo_time_t'];
        }

        // PID / ЕГН (в B-Trust сертификати обикновено е в Subject Alternative Name
        // или в serialNumber на subject)
        if ( ! empty( $cert_info['subject']['serialNumber'] ) ) {
            $details['pid'] = $cert_info['subject']['serialNumber'];
        }

        return $details;
    }

    /* ================================================================
     * 2. КОЛОНА В СПИСЪКА С ENTRIES
     * ================================================================ */

    /**
     * Добавя колона "Подписващ (CN)" в списъка с entries
     */
    public function add_signer_column( $columns, $form_id ) {
        if ( (int) $form_id === KZD_BISS_FORM_ID ) {
            $columns['biss_signer_cn'] = esc_html__( 'Подписващ (CN)', 'kzd-biss' );
        }
        return $columns;
    }

    /**
     * Рендира стойността на колоната
     */
    public function render_signer_column( $value, $form_id, $field_id, $entry ) {
        if ( $field_id === 'biss_signer_cn' ) {
            $cn = gform_get_meta( $entry['id'], 'biss_signer_cn' );
            if ( $cn ) {
                return '<span style="color:#0a7e07;font-weight:600;">🔏 ' . esc_html( $cn ) . '</span>';
            }
            return '<span style="color:#999;">— не е подписана —</span>';
        }
        return $value;
    }

    /* ================================================================
     * 3. MERGE TAGS ЗА НОТИФИКАЦИИ
     * ================================================================ */

    /**
     * Регистрира custom merge tags
     */
    public function add_merge_tags( $merge_tags, $form_id, $fields, $element_id ) {
        $merge_tags[] = [
            'label' => 'BISS: Подписващ (CN)',
            'tag'   => '{biss_signer_cn}',
        ];
        $merge_tags[] = [
            'label' => 'BISS: Имейл на подписващия',
            'tag'   => '{biss_signer_email}',
        ];
        $merge_tags[] = [
            'label' => 'BISS: Дата на подписване',
            'tag'   => '{biss_sign_timestamp}',
        ];
        return $merge_tags;
    }

    /**
     * Заменя merge tags със стойности от entry meta
     */
    public function replace_merge_tags( $text, $form, $entry, $url_encode, $esc_html, $nl2br, $format ) {
        if ( empty( $entry ) || empty( $entry['id'] ) ) {
            return $text;
        }

        $replacements = [
            '{biss_signer_cn}'       => gform_get_meta( $entry['id'], 'biss_signer_cn' ) ?: '',
            '{biss_signer_email}'    => gform_get_meta( $entry['id'], 'biss_signer_email' ) ?: '',
            '{biss_sign_timestamp}'  => gform_get_meta( $entry['id'], 'biss_sign_timestamp' ) ?: '',
        ];

        foreach ( $replacements as $tag => $value ) {
            if ( strpos( $text, $tag ) !== false ) {
                $text = str_replace( $tag, $value, $text );
            }
        }

        return $text;
    }

    /* ================================================================
     * 4. ADMIN CSS
     * ================================================================ */

    public function admin_css() {
        $screen = get_current_screen();
        if ( ! $screen || strpos( $screen->id, 'gravityforms' ) === false ) {
            return;
        }
        ?>
        <style>
            /* Meta box таблица */
            .kzd-biss-table {
                border: 0 !important;
                border-collapse: collapse;
            }
            .kzd-biss-table th.kzd-biss-label {
                width: 180px;
                padding: 10px 12px;
                font-weight: 600;
                color: #1d2327;
                vertical-align: top;
                white-space: nowrap;
                border-bottom: 1px solid #f0f0f1;
            }
            .kzd-biss-table td {
                padding: 10px 12px;
                border-bottom: 1px solid #f0f0f1;
            }
            .kzd-biss-table .dashicons {
                font-size: 16px;
                width: 16px;
                height: 16px;
                vertical-align: text-bottom;
                margin-right: 4px;
                color: #2271b1;
            }
            .kzd-biss-cn {
                font-size: 14px;
                color: #0a7e07;
            }
            .kzd-biss-expired {
                color: #d63638;
                font-weight: 700;
            }
            .kzd-biss-sig-preview {
                font-size: 11px;
                color: #666;
                cursor: pointer;
            }
            .kzd-biss-sig-full {
                width: 100%;
                font-family: monospace;
                font-size: 11px;
                margin-top: 6px;
                background: #f6f7f7;
                border: 1px solid #dcdcde;
            }
            .kzd-biss-verification-badge {
                margin-top: 12px;
                padding: 10px 14px;
                background: #edfaef;
                border-left: 4px solid #0a7e07;
                color: #0a7e07;
                font-weight: 600;
                font-size: 13px;
            }

            /* Колона в entry list */
            .column-biss_signer_cn {
                width: 180px;
            }
        </style>
        <?php
    }
}

// Инициализация
add_action( 'init', function() {
    if ( class_exists( 'GFForms' ) ) {
        KZD_BISS_Entry_Display::get_instance();
    }
});
