<?php
/**
 * Plugin Name: KZD BISS Електронно Подписване
 * Description: Интегрира BISS (Browser Independent Signing Service) с Gravity Forms
 *              за електронно подписване с КЕП на жалби/сигнали към КЗД.
 * Version:     1.0.0
 * Author:      KZD Development Team
 * Text Domain: kzd-biss
 * License:     GPL-2.0+
 *
 * Изисквания:
 *  - Gravity Forms плъгин
 *  - BISS инсталиран на клиентския компютър
 *  - SSL сертификат на сървъра (за signedContents)
 *  - PHP OpenSSL разширение
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* ================================================================
 * КОНФИГУРАЦИЯ — ПРОМЕНИ ТЕЗИ НАСТРОЙКИ
 * ================================================================ */

// ID на Gravity Form-ата за подписване
define( 'KZD_BISS_FORM_ID', 1 );

// Път до частния ключ на SSL сертификата на сървъра
// BISS изисква signedContents да е подписан с валиден сървърен сертификат
// от доверена верига (НЕ self-signed). Ползваме Let's Encrypt на kzd.bg,
// тъй като kzd-nondiscrimination.com е зад Cloudflare (self-signed на Apache).
// ВАЖНО: Let's Encrypt сертификатите се подновяват на 90 дни!
define( 'KZD_BISS_SERVER_KEY_PATH', '/home/kzdnond/ssl/sectigo_privkey.pem' );

// Път до публичния сертификат на сървъра (PEM формат, fullchain включва и intermediate)
define( 'KZD_BISS_SERVER_CERT_PATH', '/home/kzdnond/ssl/sectigo_leaf.pem' );

// Хеш алгоритъм (SHA256 или SHA512)
define( 'KZD_BISS_HASH_ALGORITHM', 'SHA256' );

// Debug логване
define( 'KZD_BISS_DEBUG', true );

/* ================================================================
 * КРАЙ НА КОНФИГУРАЦИЯТА
 * ================================================================ */

class KZD_BISS_Integration {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // CSS зареждане на всяка страница (малък overhead, JS ще скрие ако няма форма)
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );

        // REST API ендпойнти
        add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );

        // Добавяне на скрити полета към формата
        add_filter( 'gform_form_tag', [ $this, 'add_hidden_fields' ], 10, 2 );

        // Валидация — проверка дали подписът е наличен
        add_filter( 'gform_validation_' . KZD_BISS_FORM_ID, [ $this, 'validate_signature' ] );

        // Запазване на подписа с entry-то
        add_action( 'gform_after_submission_' . KZD_BISS_FORM_ID, [ $this, 'save_signature_data' ], 10, 2 );

        // Footer: BISS JavaScript и модал
        add_action( 'wp_footer', [ $this, 'render_biss_modal' ], 99 );
    }

    /**
     * Зарежда CSS и JS
     */
    public function enqueue_assets() {
        // CSS се инжектира директно в render_biss_modal()
    }

    /**
     * REST API маршрути
     */
    public function register_rest_routes() {
        // Подготовка на данни за подписване
        register_rest_route( 'kzd-biss/v1', '/prepare-sign', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rest_prepare_sign' ],
            'permission_callback' => '__return_true',
        ] );

        // Верификация на подписа
        register_rest_route( 'kzd-biss/v1', '/verify-signature', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rest_verify_signature' ],
            'permission_callback' => '__return_true',
        ] );

        // Диагностика на сертификатите (само за администратори)
        register_rest_route( 'kzd-biss/v1', '/debug-cert', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'rest_debug_cert' ],
            'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        ] );
    }

    /**
     * REST: Подготвя данните за подписване
     * Генерира signedContents и signedContentsCert за BISS
     */
    public function rest_prepare_sign( $request ) {
        $form_data_json = $request->get_param( 'formData' );

        if ( empty( $form_data_json ) ) {
            return new WP_REST_Response( [ 'error' => 'Липсват данни от формата' ], 400 );
        }

        // Зареждане на частния ключ на сървъра
        $private_key_pem = @file_get_contents( KZD_BISS_SERVER_KEY_PATH );
        if ( ! $private_key_pem ) {
            if ( KZD_BISS_DEBUG ) {
                error_log( 'KZD-BISS: Не може да се прочете частният ключ: ' . KZD_BISS_SERVER_KEY_PATH );
            }
            return new WP_REST_Response( [ 'error' => 'Сървърна грешка при подготовка на подпис' ], 500 );
        }

        $private_key = openssl_pkey_get_private( $private_key_pem );
        if ( ! $private_key ) {
            if ( KZD_BISS_DEBUG ) {
                error_log( 'KZD-BISS: Невалиден частен ключ: ' . openssl_error_string() );
            }
            return new WP_REST_Response( [ 'error' => 'Невалиден сървърен ключ' ], 500 );
        }

        // Зареждане на публичния сертификат
        $cert_pem = @file_get_contents( KZD_BISS_SERVER_CERT_PATH );
        if ( ! $cert_pem ) {
            return new WP_REST_Response( [ 'error' => 'Не може да се прочете сървърният сертификат' ], 500 );
        }

        // Извличане на base64 частта на сертификата (без BEGIN/END)
        $cert_b64 = $this->extract_cert_base64( $cert_pem );

        // Извличане на ВСИЧКИ сертификати от fullchain (leaf + intermediate)
        $all_certs_b64 = $this->extract_all_certs_base64( $cert_pem );

        // Подписване: точно както работещата НСИ система
        // contents = base64("test"), signedContents = sign("test")
        $test_data = "test";
        $algo = ( KZD_BISS_HASH_ALGORITHM === 'SHA512' ) ? OPENSSL_ALGO_SHA512 : OPENSSL_ALGO_SHA256;

        $signature = '';
        $content_hash = hash( "sha256", $test_data, true );
        $sign_ok = openssl_sign( $content_hash, $signature, $private_key, $algo );

        if ( ! $sign_ok ) {
            if ( KZD_BISS_DEBUG ) {
                error_log( 'KZD-BISS: Грешка при подписване: ' . openssl_error_string() );
            }
            return new WP_REST_Response( [ 'error' => 'Грешка при сървърно подписване' ], 500 );
        }

        // Верификация: проверяваме дали сертификатът съответства на ключа
        $cert_pubkey = openssl_pkey_get_public( $cert_pem );
        if ( ! $cert_pubkey ) {
            return new WP_REST_Response( [ 'error' => 'Невалиден публичен ключ в сертификата' ], 500 );
        }
        $verify_ok = openssl_verify( $content_hash, $signature, $cert_pubkey, $algo );
        if ( $verify_ok !== 1 ) {
            if ( KZD_BISS_DEBUG ) {
                error_log( 'KZD-BISS: Ключът и сертификатът НЕ съвпадат! verify=' . $verify_ok . ' err=' . openssl_error_string() );
            }
            return new WP_REST_Response( [ 'error' => 'Сървърният ключ и сертификат не съвпадат' ], 500 );
        }

        $signed_contents_b64 = base64_encode( $signature );

        // contents = оригиналните данни (BISS ще ги хешира вътрешно)
        $contents_b64 = base64_encode( $test_data );

        // Генериране на уникален ID за тази сесия на подписване
        $sign_session_id = wp_generate_uuid4();

        // Запазване в transient за верификация след submit
        set_transient( 'kzd_biss_session_' . $sign_session_id, [
            'data_hash'  => hash( 'sha256', $form_data_json ),
            'timestamp'  => time(),
            'form_data'  => $form_data_json,
        ], 30 * MINUTE_IN_SECONDS );

        if ( KZD_BISS_DEBUG ) {
            error_log( 'KZD-BISS: Подготвени данни за подписване. Session=' . $sign_session_id );
        }

        // BISS изисква пълната сертификатна верига (leaf + intermediate CA)
        // за да валидира signedContentsCert. Ако изпратим само leaf, връща код 500.
        if ( KZD_BISS_DEBUG ) {
            error_log( 'KZD-BISS: Изпращаме ' . count( $all_certs_b64 ) . ' сертификата във веригата' );
            // Логваме информация за всеки сертификат
            foreach ( $all_certs_b64 as $idx => $cb64 ) {
                $tmp_pem = "-----BEGIN CERTIFICATE-----\n" . chunk_split( $cb64, 64, "\n" ) . "-----END CERTIFICATE-----";
                $tmp_info = openssl_x509_parse( $tmp_pem );
                if ( $tmp_info ) {
                    error_log( 'KZD-BISS: Cert[' . $idx . '] Subject: ' . ( $tmp_info['subject']['CN'] ?? 'N/A' )
                        . ' | Issuer: ' . ( $tmp_info['issuer']['CN'] ?? 'N/A' )
                        . ' | Valid: ' . date( 'Y-m-d', $tmp_info['validFrom_time_t'] ?? 0 )
                        . ' → ' . date( 'Y-m-d', $tmp_info['validTo_time_t'] ?? 0 ) );
                }
            }
        }

        return new WP_REST_Response( [
            'success'             => true,
            'contents'            => [ $contents_b64 ],
            'signedContents'      => [ $signed_contents_b64 ],
            'signedContentsCert'  => [ $cert_b64 ],
            'hashAlgorithm'       => KZD_BISS_HASH_ALGORITHM,
            'signSessionId'       => $sign_session_id,
        ], 200 );
    }

    /**
     * REST: Диагностика на SSL сертификатите (само за администратори)
     * Достъп: GET /wp-json/kzd-biss/v1/debug-cert
     */
    public function rest_debug_cert( $request ) {
        $result = [
            'key_path'  => KZD_BISS_SERVER_KEY_PATH,
            'cert_path' => KZD_BISS_SERVER_CERT_PATH,
            'key_exists' => file_exists( KZD_BISS_SERVER_KEY_PATH ),
            'cert_exists' => file_exists( KZD_BISS_SERVER_CERT_PATH ),
        ];

        // Проверка на сертификата
        $cert_pem = @file_get_contents( KZD_BISS_SERVER_CERT_PATH );
        if ( $cert_pem ) {
            // Брой сертификати във файла
            preg_match_all( '/-----BEGIN CERTIFICATE-----/', $cert_pem, $m );
            $result['certs_in_file'] = count( $m[0] );

            // Информация за всеки сертификат
            $all_certs = [];
            if ( preg_match_all( '/-----BEGIN CERTIFICATE-----(.+?)-----END CERTIFICATE-----/s', $cert_pem, $matches ) ) {
                foreach ( $matches[0] as $idx => $full_cert ) {
                    $info = openssl_x509_parse( $full_cert );
                    if ( $info ) {
                        $all_certs[] = [
                            'index'       => $idx,
                            'subject_CN'  => $info['subject']['CN'] ?? 'N/A',
                            'issuer_CN'   => $info['issuer']['CN'] ?? 'N/A',
                            'issuer_O'    => $info['issuer']['O'] ?? 'N/A',
                            'valid_from'  => date( 'Y-m-d H:i:s', $info['validFrom_time_t'] ?? 0 ),
                            'valid_to'    => date( 'Y-m-d H:i:s', $info['validTo_time_t'] ?? 0 ),
                            'is_expired'  => ( $info['validTo_time_t'] ?? 0 ) < time(),
                            'serial'      => $info['serialNumberHex'] ?? 'N/A',
                        ];
                    }
                }
            }
            $result['certificates'] = $all_certs;

            // Проверка дали ключ и сертификат съвпадат
            $private_key_pem = @file_get_contents( KZD_BISS_SERVER_KEY_PATH );
            if ( $private_key_pem ) {
                $private_key = openssl_pkey_get_private( $private_key_pem );
                $cert_pubkey = openssl_pkey_get_public( $cert_pem );
                if ( $private_key && $cert_pubkey ) {
                    $test = 'test';
                    $sig = '';
                    openssl_sign( $test, $sig, $private_key, OPENSSL_ALGO_SHA256 );
                    $verify = openssl_verify( $test, $sig, $cert_pubkey, OPENSSL_ALGO_SHA256 );
                    $result['key_cert_match'] = ( $verify === 1 );
                } else {
                    $result['key_cert_match'] = false;
                    $result['openssl_error'] = openssl_error_string();
                }
            }
        } else {
            $result['cert_read_error'] = 'Cannot read cert file';
        }

        return new WP_REST_Response( $result, 200 );
    }

    /**
     * REST: Верифицира подпис (опционално)
     */
    public function rest_verify_signature( $request ) {
        $signature_b64 = $request->get_param( 'signature' );
        $cert_chain    = $request->get_param( 'chain' );
        $session_id    = $request->get_param( 'signSessionId' );

        if ( empty( $signature_b64 ) || empty( $cert_chain ) || empty( $session_id ) ) {
            return new WP_REST_Response( [ 'valid' => false, 'error' => 'Липсващи параметри' ], 400 );
        }

        // Проверка на сесията
        $session = get_transient( 'kzd_biss_session_' . $session_id );
        if ( ! $session ) {
            return new WP_REST_Response( [ 'valid' => false, 'error' => 'Изтекла сесия на подписване' ], 400 );
        }

        // Декодиране на клиентския сертификат (първият от веригата)
        $client_cert_b64 = $cert_chain[0] ?? '';
        $client_cert_pem = "-----BEGIN CERTIFICATE-----\n"
                         . chunk_split( $client_cert_b64, 64, "\n" )
                         . "-----END CERTIFICATE-----";

        // Извличане на публичния ключ от клиентския сертификат
        $cert_resource = openssl_x509_read( $client_cert_pem );
        if ( ! $cert_resource ) {
            return new WP_REST_Response( [ 'valid' => false, 'error' => 'Невалиден клиентски сертификат' ], 400 );
        }

        $public_key = openssl_pkey_get_public( $cert_resource );
        $cert_info  = openssl_x509_parse( $cert_resource );

        // Верификация на подписа
        $data      = base64_decode( $session['form_data'] );
        $signature = base64_decode( $signature_b64 );
        $algo      = ( KZD_BISS_HASH_ALGORITHM === 'SHA512' ) ? OPENSSL_ALGO_SHA512 : OPENSSL_ALGO_SHA256;

        // Note: BISS подписва хеша на данните, не самите данни директно
        // Затова верификацията зависи от конкретната имплементация
        $verify_result = openssl_verify( $data, $signature, $public_key, $algo );

        $cn    = $cert_info['subject']['CN'] ?? '';
        $email = $cert_info['subject']['emailAddress'] ?? '';

        return new WP_REST_Response( [
            'valid'     => ( $verify_result === 1 ),
            'cn'        => $cn,
            'email'     => $email,
            'issuer'    => $cert_info['issuer']['O'] ?? '',
            'validTo'   => date( 'Y-m-d', $cert_info['validTo_time_t'] ?? 0 ),
        ], 200 );
    }

    /**
     * Добавя скрити полета към формата за съхранение на подписа
     */
    public function add_hidden_fields( $form_tag, $form ) {
        if ( (int) $form['id'] !== KZD_BISS_FORM_ID ) {
            return $form_tag;
        }

        $hidden = '<input type="hidden" name="kzd_biss_signature" id="kzd_biss_signature" value="">';
        $hidden .= '<input type="hidden" name="kzd_biss_cert_chain" id="kzd_biss_cert_chain" value="">';
        $hidden .= '<input type="hidden" name="kzd_biss_sign_session" id="kzd_biss_sign_session" value="">';
        $hidden .= '<input type="hidden" name="kzd_biss_signer_cn" id="kzd_biss_signer_cn" value="">';
        $hidden .= '<input type="hidden" name="kzd_biss_signer_email" id="kzd_biss_signer_email" value="">';
        $hidden .= '<input type="hidden" name="kzd_biss_sign_timestamp" id="kzd_biss_sign_timestamp" value="">';

        return $form_tag . $hidden;
    }

    /**
     * Валидация: проверява дали формата е подписана
     */
    public function validate_signature( $validation_result ) {
        $signature = rgpost( 'kzd_biss_signature' );

        if ( empty( $signature ) ) {
            $validation_result['is_valid'] = false;

            // Маркираме грешка на последното поле
            foreach ( $validation_result['form']['fields'] as &$field ) {
                if ( $field->type === 'radio' && $field->id == 22 ) {
                    $field->failed_validation  = true;
                    $field->validation_message = 'Моля, подпишете формата с електронен подпис (КЕП) преди изпращане.';
                    break;
                }
            }
        }

        return $validation_result;
    }

    /**
     * Запазва данните от подписа като entry meta
     */
    public function save_signature_data( $entry, $form ) {
        $signature   = rgpost( 'kzd_biss_signature' );
        $cert_chain  = rgpost( 'kzd_biss_cert_chain' );
        $session_id  = rgpost( 'kzd_biss_sign_session' );
        $signer_cn   = rgpost( 'kzd_biss_signer_cn' );
        $signer_email = rgpost( 'kzd_biss_signer_email' );
        $timestamp   = rgpost( 'kzd_biss_sign_timestamp' );

        if ( ! empty( $signature ) ) {
            gform_update_meta( $entry['id'], 'biss_signature', $signature );
            gform_update_meta( $entry['id'], 'biss_cert_chain', $cert_chain );
            gform_update_meta( $entry['id'], 'biss_sign_session', $session_id );
            gform_update_meta( $entry['id'], 'biss_signer_cn', sanitize_text_field( $signer_cn ) );
            gform_update_meta( $entry['id'], 'biss_signer_email', sanitize_email( $signer_email ) );
            gform_update_meta( $entry['id'], 'biss_sign_timestamp', sanitize_text_field( $timestamp ) );

            if ( KZD_BISS_DEBUG ) {
                error_log( 'KZD-BISS: Подпис запазен за entry #' . $entry['id'] . ' от ' . $signer_cn );
            }
        }

        // Изтриване на transient сесията
        if ( ! empty( $session_id ) ) {
            delete_transient( 'kzd_biss_session_' . $session_id );
        }
    }

    /**
     * Извлича base64 от PEM сертификат (само първия/leaf сертификат от fullchain)
     */
    private function extract_cert_base64( $pem ) {
        // fullchain.pem съдържа няколко сертификата — взимаме само първия (leaf)
        if ( preg_match( '/-----BEGIN CERTIFICATE-----(.+?)-----END CERTIFICATE-----/s', $pem, $matches ) ) {
            return str_replace( [ "\r", "\n", ' ' ], '', trim( $matches[1] ) );
        }
        // Fallback
        $pem = str_replace( [ '-----BEGIN CERTIFICATE-----', '-----END CERTIFICATE-----', "\r", "\n", ' ' ], '', $pem );
        return trim( $pem );
    }

    /**
     * Извлича ВСИЧКИ сертификати от PEM файл (fullchain) като масив от base64 стрингове
     */
    private function extract_all_certs_base64( $pem ) {
        $certs = [];
        if ( preg_match_all( '/-----BEGIN CERTIFICATE-----(.+?)-----END CERTIFICATE-----/s', $pem, $matches ) ) {
            foreach ( $matches[1] as $cert_body ) {
                $certs[] = str_replace( [ "\r", "\n", ' ' ], '', trim( $cert_body ) );
            }
        }
        return $certs;
    }

    /**
     * Рендира BISS модалния прозорец и JavaScript
     */
    public function render_biss_modal() {
        // Рендираме винаги - JavaScript ще провери дали формата е на страницата
        ?>
        <style><?php echo $this->get_css(); ?></style>
        <!-- KZD BISS Signing Modal -->
        <div id="kzd-biss-overlay" class="kzd-biss-overlay" role="dialog" aria-modal="true"
             aria-labelledby="kzd-biss-title" style="display:none;">
            <div class="kzd-biss-modal">
                <h2 id="kzd-biss-title">🔐 Електронно подписване с КЕП</h2>

                <!-- Стъпка 0: Проверка на BISS -->
                <div id="kzd-biss-step-detect" class="kzd-biss-step">
                    <div class="kzd-biss-spinner" aria-label="Зареждане"></div>
                    <p>Търсене на BISS на вашия компютър...</p>
                </div>

                <!-- Стъпка 0.5: BISS не е намерен -->
                <div id="kzd-biss-step-not-found" class="kzd-biss-step" style="display:none;">
                    <div class="kzd-biss-error-icon" aria-hidden="true">⚠️</div>
                    <h3>BISS не е намерен</h3>
                    <p>За електронно подписване е необходимо приложението <strong>BISS</strong> да е инсталирано и стартирано.</p>
                    <ol>
                        <li>Изтеглете BISS от <a href="https://store.borica.bg/bg/b-trust/certificates/biss" target="_blank" rel="noopener">store.borica.bg</a></li>
                        <li>Инсталирайте го</li>
                        <li>Стартирайте BISS</li>
                        <li>Натиснете „Опитай отново"</li>
                    </ol>
                    <div class="kzd-biss-buttons">
                        <button type="button" class="kzd-biss-btn kzd-biss-btn-primary" onclick="kzdBiss.detectBiss()">Опитай отново</button>
                        <button type="button" class="kzd-biss-btn kzd-biss-btn-secondary" onclick="kzdBiss.closeModal()">Затвори</button>
                    </div>
                </div>

                <!-- Стъпка 1: BISS намерен, подготовка -->
                <div id="kzd-biss-step-found" class="kzd-biss-step" style="display:none;">
                    <div class="kzd-biss-success-icon" aria-hidden="true">✅</div>
                    <h3>BISS е стартиран <span id="kzd-biss-version"></span></h3>
                    <p>Натиснете бутона за да изберете Вашия електронен подпис (КЕП) и да подпишете жалбата/сигнала.</p>
                    <div class="kzd-biss-buttons">
                        <button type="button" class="kzd-biss-btn kzd-biss-btn-primary" onclick="kzdBiss.startSigning()">
                            ✍️ Подпиши с КЕП
                        </button>
                        <button type="button" class="kzd-biss-btn kzd-biss-btn-secondary" onclick="kzdBiss.closeModal()">Отказ</button>
                    </div>
                </div>

                <!-- Стъпка 2: Подписване в процес -->
                <div id="kzd-biss-step-signing" class="kzd-biss-step" style="display:none;">
                    <div class="kzd-biss-spinner" aria-label="Подписване"></div>
                    <h3>Подписване...</h3>
                    <p id="kzd-biss-signing-status">Изберете сертификат и въведете ПИН кода в прозореца на BISS.</p>
                </div>

                <!-- Стъпка 3: Успех -->
                <div id="kzd-biss-step-success" class="kzd-biss-step" style="display:none;">
                    <div class="kzd-biss-success-icon" aria-hidden="true">✅</div>
                    <h3>Успешно подписано!</h3>
                    <div id="kzd-biss-signer-info"></div>
                    <p>Формата ще бъде изпратена автоматично.</p>
                </div>

                <!-- Стъпка 4: Грешка -->
                <div id="kzd-biss-step-error" class="kzd-biss-step" style="display:none;">
                    <div class="kzd-biss-error-icon" aria-hidden="true">❌</div>
                    <h3>Грешка при подписване</h3>
                    <p id="kzd-biss-error-text"></p>
                    <div class="kzd-biss-buttons">
                        <button type="button" class="kzd-biss-btn kzd-biss-btn-primary" onclick="kzdBiss.startSigning()">Опитай отново</button>
                        <button type="button" class="kzd-biss-btn kzd-biss-btn-secondary" onclick="kzdBiss.closeModal()">Затвори</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
        /**
         * KZD BISS Integration
         * Комуникира с BISS на localhost:53952-53955
         */
        var kzdBiss = (function() {
            "use strict";

            var BISS_PORTS = [53952, 53953, 53954, 53955];
            var FORM_ID = <?php echo (int) KZD_BISS_FORM_ID; ?>;
            var REST_URL = "<?php echo esc_url( rest_url( 'kzd-biss/v1' ) ); ?>";
            var NONCE = "<?php echo wp_create_nonce( 'wp_rest' ); ?>";

            var state = {
                bissPort: null,
                bissVersion: null,
                signerCert: null,
                signerChain: null,
                formDataJson: null
            };

            /* ========== MODAL ========== */

            function showStep(stepId) {
                var steps = document.querySelectorAll(".kzd-biss-step");
                for (var i = 0; i < steps.length; i++) {
                    steps[i].style.display = "none";
                }
                var el = document.getElementById("kzd-biss-step-" + stepId);
                if (el) el.style.display = "block";
            }

            function openModal() {
                document.getElementById("kzd-biss-overlay").style.display = "flex";
                document.body.style.overflow = "hidden";
            }

            function closeModal() {
                document.getElementById("kzd-biss-overlay").style.display = "none";
                document.body.style.overflow = "";
            }

            /* ========== BISS DETECTION ========== */

            function detectBiss() {
                openModal();
                showStep("detect");
                tryNextPort(0);
            }

            function tryNextPort(idx) {
                if (idx >= BISS_PORTS.length) {
                    showStep("not-found");
                    return;
                }

                var port = BISS_PORTS[idx];
                var url = "https://localhost:" + port + "/version";

                fetch(url, { method: "GET", mode: "cors", targetAddressSpace: "loopback" })
                    .then(function(resp) { return resp.json(); })
                    .then(function(data) {
                        if (data && data.version) {
                            state.bissPort = port;
                            state.bissVersion = data.version;
                            document.getElementById("kzd-biss-version").textContent = "(v" + data.version + ")";
                            showStep("found");
                        } else {
                            tryNextPort(idx + 1);
                        }
                    })
                    .catch(function() {
                        tryNextPort(idx + 1);
                    });
            }

            /* ========== COLLECT FORM DATA ========== */

            function collectFormData() {
                var form = document.getElementById("gform_" + FORM_ID);
                if (!form) return null;

                var data = {};
                var elements = form.querySelectorAll("input, textarea, select");

                for (var i = 0; i < elements.length; i++) {
                    var el = elements[i];
                    var name = el.name;
                    if (!name || name.indexOf("kzd_biss_") === 0) continue;

                    if (el.type === "checkbox" || el.type === "radio") {
                        if (el.checked) {
                            if (data[name]) {
                                if (!Array.isArray(data[name])) data[name] = [data[name]];
                                data[name].push(el.value);
                            } else {
                                data[name] = el.value;
                            }
                        }
                    } else if (el.type === "file") {
                        if (el.files && el.files.length > 0) {
                            var fileNames = [];
                            for (var f = 0; f < el.files.length; f++) {
                                fileNames.push(el.files[f].name + " (" + el.files[f].size + " bytes)");
                            }
                            data[name] = fileNames;
                        }
                    } else {
                        data[name] = el.value;
                    }
                }

                // Добавяме timestamp
                data._sign_timestamp = new Date().toISOString();
                data._form_id = FORM_ID;

                return JSON.stringify(data, null, 0);
            }

            /* ========== SIGNING FLOW ========== */

            function startSigning() {
                showStep("signing");
                document.getElementById("kzd-biss-signing-status").textContent =
                    "Подготовка на данните за подписване...";

                // 1. Събиране на данни от формата
                state.formDataJson = collectFormData();
                if (!state.formDataJson) {
                    showError("Не може да се съберат данните от формата.");
                    return;
                }

                // 2. Избор на сертификат (getsigner)
                document.getElementById("kzd-biss-signing-status").textContent =
                    "Моля, изберете сертификат от прозореца на BISS...";

                var getSignerUrl = "https://localhost:" + state.bissPort + "/getsigner";

                fetch(getSignerUrl, {
                    method: "POST",
                    mode: "cors",
                    targetAddressSpace: "loopback",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        selector: {
                            keyusages: ["nonRepudation"]
                        },
                        showValidCerts: true
                    })
                })
                .then(function(resp) { return resp.json(); })
                .then(function(data) {
                    if (data.status === "ok" && data.chain && data.chain.length > 0) {
                        state.signerCert = data.chain[0];
                        state.signerChain = data.chain;
                        prepareAndSign();
                    } else {
                        var errMsg = data.reasonText || "Не е избран сертификат";
                        if (data.reasonCode == 401) {
                            errMsg = "Не е избран сертификат или е въведен грешен ПИН.";
                        }
                        showError(errMsg);
                    }
                })
                .catch(function(err) {
                    showError("Грешка при комуникация с BISS: " + err.message);
                });
            }

            function prepareAndSign() {
                document.getElementById("kzd-biss-signing-status").textContent =
                    "Подготовка на подписа на сървъра...";

                // 3. Изпращане до сървъра за подготовка на signedContents
                fetch(REST_URL + "/prepare-sign", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-WP-Nonce": NONCE
                    },
                    body: JSON.stringify({
                        formData: state.formDataJson
                    })
                })
                .then(function(resp) { return resp.json(); })
                .then(function(serverData) {
                    if (serverData.error) {
                        showError("Сървърна грешка: " + serverData.error);
                        return;
                    }

                    document.getElementById("kzd-biss-signing-status").textContent =
                        "Моля, въведете ПИН кода в прозореца на BISS...";

                    // 4. Подписване чрез BISS
                    var signUrl = "https://localhost:" + state.bissPort + "/sign";

                    var signRequest = {
                        version: "1.0",
                        signatureType: "signature",
                        hashAlgorithm: serverData.hashAlgorithm || "SHA256",
                        contentType: "digest",
                        contents: serverData.contents,
                        signedContents: serverData.signedContents,
                        signedContentsCert: serverData.signedContentsCert,
                        signerCertificateB64: state.signerCert,
                        confirmText: ["Подписване на жалба/сигнал към КЗД"],
                        cert: false
                    };

                    return fetch(signUrl, {
                        method: "POST",
                        mode: "cors",
                        targetAddressSpace: "loopback",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(signRequest)
                    });
                })
                .then(function(resp) { if (resp) return resp.json(); })
                .then(function(signResult) {
                    if (!signResult) return;

                    if (signResult.status === "ok" && signResult.signatures) {
                        onSigningSuccess(signResult);
                    } else {
                        var errMsg = signResult.reasonText || "Подписването не е успешно";
                        showError(errMsg + " (код: " + signResult.reasonCode + ")");
                    }
                })
                .catch(function(err) {
                    showError("Грешка: " + err.message);
                });
            }

            function onSigningSuccess(signResult) {
                // Извличане на информация от сертификата (base64 decode на subject)
                var signerInfo = parseCertificateSubject(state.signerCert);

                // Попълване на скритите полета
                document.getElementById("kzd_biss_signature").value = signResult.signatures[0];
                document.getElementById("kzd_biss_cert_chain").value = JSON.stringify(state.signerChain);
                document.getElementById("kzd_biss_sign_session").value = state.signSessionId || "";
                document.getElementById("kzd_biss_signer_cn").value = signerInfo.cn || "";
                document.getElementById("kzd_biss_signer_email").value = signerInfo.email || "";
                document.getElementById("kzd_biss_sign_timestamp").value = new Date().toISOString();

                // Показване на успех
                var infoHtml = "<p><strong>Подписал:</strong> " + escapeHtml(signerInfo.cn || "N/A") + "</p>";
                if (signerInfo.email) {
                    infoHtml += "<p><strong>Email:</strong> " + escapeHtml(signerInfo.email) + "</p>";
                }
                document.getElementById("kzd-biss-signer-info").innerHTML = infoHtml;
                showStep("success");

                // Автоматично submit след 2 секунди
                setTimeout(function() {
                    closeModal();
                    // Тригерираме submit на Gravity Forms
                    var submitBtn = document.getElementById("gform_submit_button_" + FORM_ID);
                    if (submitBtn) {
                        // Маркираме че вече е подписано, за да не се отвори модалът пак
                        state.signed = true;
                        submitBtn.click();
                    }
                }, 2000);
            }

            /* ========== HELPERS ========== */

            function showError(message) {
                document.getElementById("kzd-biss-error-text").textContent = message;
                showStep("error");
            }

            function escapeHtml(text) {
                var div = document.createElement("div");
                div.textContent = text;
                return div.innerHTML;
            }

            /**
             * Парсва base64 сертификат за извличане на CN и email
             * (Опростена версия — извлича от Subject DN)
             */
            function parseCertificateSubject(certB64) {
                try {
                    var binary = atob(certB64);
                    // Търсим CN= и emailAddress= в DER encoded cert
                    // Грубо търсене в raw bytes за четими стрингове
                    var text = "";
                    for (var i = 0; i < binary.length; i++) {
                        var c = binary.charCodeAt(i);
                        if (c >= 32 && c < 127) {
                            text += binary[i];
                        } else {
                            text += "|";
                        }
                    }

                    var cn = "";
                    var email = "";

                    // Търсене на CN
                    var cnPatterns = [/CN=([^|,\/]+)/i, /commonName[|]*([^|,]{3,})/i];
                    for (var p = 0; p < cnPatterns.length; p++) {
                        var m = text.match(cnPatterns[p]);
                        if (m && m[1]) {
                            cn = m[1].trim();
                            break;
                        }
                    }

                    // Търсене на email
                    var emailMatch = text.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
                    if (emailMatch) {
                        email = emailMatch[1];
                    }

                    return { cn: cn, email: email };
                } catch (e) {
                    return { cn: "", email: "" };
                }
            }

            /* ========== INTERCEPT FORM SUBMIT ========== */

            function init() {
                if (typeof jQuery === "undefined") return;

                jQuery(document).on("gform_post_render", function(event, formId) {
                    if (parseInt(formId) !== FORM_ID) return;

                    var form = document.getElementById("gform_" + FORM_ID);
                    if (!form) return;

                    // Прехващане на submit бутона
                    var submitBtn = document.getElementById("gform_submit_button_" + FORM_ID);
                    if (submitBtn && !submitBtn.dataset.bissHooked) {
                        submitBtn.dataset.bissHooked = "1";

                        submitBtn.addEventListener("click", function(e) {
                            // Ако вече е подписано, позволяваме submit
                            if (state.signed) return;

                            // Ако няма подпис, спираме submit и отваряме BISS
                            var sig = document.getElementById("kzd_biss_signature").value;
                            if (!sig) {
                                e.preventDefault();
                                e.stopPropagation();
                                detectBiss();
                                return false;
                            }
                        }, true);
                    }
                });

                // Trigger за вече заредени форми
                var existingForm = document.getElementById("gform_" + FORM_ID);
                if (existingForm) {
                    jQuery(document).trigger("gform_post_render", [FORM_ID]);
                }
            }

            // Стартиране
            if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", init);
            } else {
                init();
            }

            /* ========== PUBLIC API ========== */
            return {
                detectBiss: detectBiss,
                startSigning: startSigning,
                closeModal: closeModal,
                getState: function() { return state; }
            };

        })();
        </script>
        <?php
    }

    /**
     * Inline CSS
     */
    private function get_css() {
        return '
/* KZD BISS Modal */
.kzd-biss-overlay {
    display: none;
    position: fixed;
    inset: 0;
    z-index: 999999;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    align-items: center;
    justify-content: center;
    padding: 20px;
}
.kzd-biss-modal {
    background: #fff;
    border-radius: 12px;
    padding: 32px;
    max-width: 520px;
    width: 100%;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    text-align: center;
    font-family: "Segoe UI", system-ui, sans-serif;
}
.kzd-biss-modal h2 {
    margin: 0 0 20px;
    font-size: 22px;
    color: #1a1a2e;
}
.kzd-biss-modal h3 {
    margin: 10px 0;
    font-size: 18px;
    color: #333;
}
.kzd-biss-modal p {
    color: #555;
    line-height: 1.6;
    margin: 8px 0;
}
.kzd-biss-modal ol {
    text-align: left;
    color: #555;
    line-height: 1.8;
}
.kzd-biss-success-icon,
.kzd-biss-error-icon {
    font-size: 48px;
    margin: 10px 0;
}

/* Spinner */
.kzd-biss-spinner {
    width: 48px;
    height: 48px;
    border: 4px solid #e0e0e0;
    border-top-color: #0073aa;
    border-radius: 50%;
    animation: kzd-biss-spin 0.8s linear infinite;
    margin: 20px auto;
}
@keyframes kzd-biss-spin {
    to { transform: rotate(360deg); }
}

/* Buttons */
.kzd-biss-buttons {
    display: flex;
    gap: 12px;
    justify-content: center;
    margin-top: 20px;
    flex-wrap: wrap;
}
.kzd-biss-btn {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s, transform 0.1s, box-shadow 0.2s;
    min-width: 140px;
}
.kzd-biss-btn:active {
    transform: scale(0.97);
}
.kzd-biss-btn:focus-visible {
    outline: 3px solid #005177;
    outline-offset: 2px;
}
.kzd-biss-btn-primary {
    background: #0073aa;
    color: #fff;
}
.kzd-biss-btn-primary:hover {
    background: #005d8c;
    box-shadow: 0 4px 12px rgba(0,115,170,0.3);
}
.kzd-biss-btn-secondary {
    background: #e9ecef;
    color: #333;
}
.kzd-biss-btn-secondary:hover {
    background: #dee2e6;
}

/* Signer info */
#kzd-biss-signer-info {
    background: #d4edda;
    border-radius: 8px;
    padding: 12px 16px;
    margin: 12px 0;
    text-align: left;
}
#kzd-biss-signer-info p {
    margin: 4px 0;
    color: #155724;
}

/* Responsive */
@media (max-width: 480px) {
    .kzd-biss-modal {
        padding: 20px;
    }
    .kzd-biss-btn {
        min-width: 120px;
        padding: 10px 16px;
    }
}
';
    }
}

// Инициализация
KZD_BISS_Integration::get_instance();
