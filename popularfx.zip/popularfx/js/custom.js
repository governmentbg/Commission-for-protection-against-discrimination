//
document.addEventListener('DOMContentLoaded', function () {
    setTimeout(function () {
        const toggles = document.querySelectorAll('.submenu-toggle');
        toggles.forEach(btn => {
            btn.addEventListener('click', function () {
                const submenu = this.parentElement.querySelector('.sub-menu');
                const expanded = this.getAttribute('aria-expanded') === 'true';
                submenu.style.display = expanded ? 'none' : 'block';
                this.setAttribute('aria-expanded', expanded ? 'false' : 'true');
            });
        });
    }, 500); // изчаква 100 милисекунди преди да добави слушателите
});

// RENDER MENU
document.addEventListener("DOMContentLoaded", function () {
    if (window.location.search.includes('pagelayer')) {
        return; // Не правим нищо в PageLayer редактора
    }

    var menu = document.querySelector(".left-sidebar-menu");
    var target1 = document.querySelector(".pagelayer-content");
    var target2 = document.querySelector(".custom-mega-menu");

    var alreadyInsertedInTarget1 = target1 && target1.querySelector(".left-sidebar-menu");
    var alreadyInsertedInTarget2 = target2 && target2.querySelector(".mega-menu");

    if (menu) {
        if (target1 && !alreadyInsertedInTarget1) {
            var cloned1 = menu.cloneNode(true);
            cloned1.style.display = "block";
            target1.insertBefore(cloned1, target1.firstChild);
        }
        if (target2 && !alreadyInsertedInTarget2) {
            var cloned2 = menu.cloneNode(true);
            cloned2.classList.remove("left-sidebar-menu");
            cloned2.classList.add("mega-menu");
            cloned2.style.display = "block";
            target2.insertBefore(cloned2, target2.firstChild);
        }
    }
});




// SEARCH
document.addEventListener("DOMContentLoaded", function () {
    const lang = document.documentElement.lang; // "bg" или "en"
    const target = document.querySelector(".pagelayer-header .right-column .pagelayer-col-holder");

    if (target) {
        const buttonSearch = document.createElement("button");
        buttonSearch.className = "button open-close-search";

        const iconSearch = document.createElement("i");
        iconSearch.className = "fas fa-search";

        const spanSearch = document.createElement("span");
        spanSearch.textContent = (lang === 'en-US') ? "Search" : "Търсене";

        buttonSearch.appendChild(iconSearch);
        buttonSearch.appendChild(spanSearch);
        target.appendChild(buttonSearch);
    } else {
        console.warn("Не е намерен елемент с посочените класове.");
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const toggleButtonSearch = document.querySelector('.open-close-search');
    const search = document.querySelector('.custom-header-search');
    const searchWrapper = document.querySelector('.custom-search-wrapper');

    if (toggleButtonSearch && search && searchWrapper) {
        toggleButtonSearch.addEventListener('click', function () {
            const isOpening = !search.classList.contains('open');

            search.classList.toggle('open');

            if (isOpening) {
                searchWrapper.style.zIndex = '5';
            } else {
                // Изчакваме 1 секунда преди да премахнем z-index
                setTimeout(function () {
                    searchWrapper.style.zIndex = '';
                }, 450);
            }
        });
    }
});

document.addEventListener("DOMContentLoaded", function () {
    const lang = document.documentElement.lang; // "bg" или "en"
    const target = document.querySelector(".pagelayer-header .right-column .pagelayer-col-holder");

    console.log("Language:", lang);
    if (target) {
        const buttonMegaMenu = document.createElement("button");
        buttonMegaMenu.className = "button open-close-mega-menu";

        const iconMegaMenu = document.createElement("i");
        iconMegaMenu.className = "fas fa-bars";

        const spanMegaMenu = document.createElement("span");
        // Задай текст спрямо езика
        spanMegaMenu.textContent = (lang === 'en-US') ? "Menu" : "Меню";

        buttonMegaMenu.appendChild(iconMegaMenu);
        buttonMegaMenu.appendChild(spanMegaMenu);
        target.appendChild(buttonMegaMenu);
    } else {
        console.warn("Не е намерен елемент с посочените класове.");
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const toggleButtonMEgaMenu = document.querySelector('.open-close-mega-menu');
    const megaMenu = document.querySelector('.custom-mega-menu');
    const megaMenuWrapper = document.querySelector('.custom-mega-menu-wrapper');

    if (toggleButtonMEgaMenu && megaMenu && megaMenuWrapper) {
        toggleButtonMEgaMenu.addEventListener('click', function () {
            const isOpening = !megaMenu.classList.contains('open');

            megaMenu.classList.toggle('open');

            if (isOpening) {
                megaMenuWrapper.style.zIndex = '5';
            } else {
                // Изчакваме 1 секунда преди да премахнем z-index
                setTimeout(function () {
                    megaMenuWrapper.style.zIndex = '';
                }, 450);
            }
        });
    }
});