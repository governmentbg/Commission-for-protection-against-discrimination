<?php
/**
 * Template Name: Страница с новини по категория
 */
add_filter('sidebars_widgets', function($w){ $w['sidebar-1'] = array(); return $w; }, 999);
get_header();

$cat_id = (int) get_post_meta(get_the_ID(), '_kzd_page_category', true);
$paged  = max(1, (int) get_query_var('paged'), (int) get_query_var('page'));
?>
<style>
.kzd-posts-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin:30px 0;width:900px;max-width:none}
.kzd-post-card{min-width:0}
.kzd-post-card img{width:100%;height:auto;display:block;margin-bottom:10px}
.kzd-post-card h2{font-size:15px;line-height:1.4;margin:0 0 4px;font-weight:400}
.kzd-post-card h2 a{color:#1a5fb4;text-decoration:none}
.kzd-post-card img{aspect-ratio:16/9;object-fit:cover}
.kzd-date{color:#666;font-size:13px;margin:0 0 8px}
.kzd-pagination{margin:30px 0;text-align:center}
.kzd-pagination .page-numbers{display:inline-block;padding:6px 12px;margin:0 3px;border:1px solid #ddd}
.kzd-pagination .current{background:#0b5cab;color:#fff;border-color:#0b5cab}
</style>
<main id="primary" class="site-main">
<?php
while (have_posts()) : the_post(); ?>
    <h1 class="entry-title"><?php the_title(); ?></h1>
    <div class="entry-content"><?php the_content(); ?></div>
<?php
endwhile;

if ($cat_id) {
    $q = new WP_Query(array(
        'post_type'           => 'post',
        'post_status'         => 'publish',
        'cat'                 => $cat_id,
        'posts_per_page'      => 6,
        'paged'               => $paged,
        'ignore_sticky_posts' => true,
        'kzd_cat_page'        => true,
    ));

    if ($q->have_posts()) {
        echo '<div class="kzd-posts-grid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin:30px 0;">';
        while ($q->have_posts()) : $q->the_post(); ?>
            <article class="kzd-post-card">
                <?php if (has_post_thumbnail()) : ?>
                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
                <?php endif; ?>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <p class="kzd-date"><?php echo get_the_date('d.m.Y'); ?></p>
            </article>
        <?php endwhile;
        echo '</div>';

        if ($q->max_num_pages > 1) {
            echo '<div class="kzd-pagination">' . paginate_links(array(
                'total'     => $q->max_num_pages,
                'current'   => $paged,
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
            )) . '</div>';
        }
        wp_reset_postdata();
    } else {
        echo '<p>Няма публикации в тази категория.</p>';
    }
} else {
    echo '<p><em>Изберете категория от панела „Категория за тази страница" вдясно в редактора.</em></p>';
}
?>
</main>
<?php get_footer();
